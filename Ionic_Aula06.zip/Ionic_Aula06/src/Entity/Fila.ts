export class Fila{
    nome: string;
    imagem: string;
    id: string;

    constructor(id){
        this.id = id;
    }
}